/*
shatee Wardlaw 4/28/25
*/
function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
 
  button(200,200,'yellow');
  button(100,100,50, 'blue');
  button(300,300,200, 'purple')
  
}
 function button (x , y, s,c){
   //calculate distance between circle origin and mouse 
var d = dist(x,y, mouseX, mouseY); 
   if(d < s / 2){
    fill(c);
  }else {
   circle(x,y,s,c);
  }
 }