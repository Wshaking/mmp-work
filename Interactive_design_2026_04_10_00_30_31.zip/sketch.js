/* Shatee Wardlaw
Feb 24,2025
*/

let x=200;
let y=20;
function setup() {
  createCanvas(400, 400);
  x=mouseX;
  let bgColor = map(mouseX,0,height ,200,0);
  fill(bgColor + y , bgColor + y,bgColor);
}

function draw() {
  background(220,400);
  stroke(10);
  // circle has a stroke function with inner color changes 
  circle(200,200,200,);
  noStroke();
  // move rect to make color change 
  rect(mouseX,mouseY,100,100);
  let bgColor = map(mouseX,0,height ,200,0);
  fill(bgColor + 0 , bgColor + 400, bgColor - 250,);
    fill(bgColor + 400 + 0, bgColor - 200,bgColor);
   let y =map(mouseY,200,0,height,200,0);
   let r = map(mouseX, 0, width, 0, 255);
  let g = map(mouseY, 0, height, 0, 300);
{
}
    function mousePressed(){
    save('sketch.js.png')
    }
}