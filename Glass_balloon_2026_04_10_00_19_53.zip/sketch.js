/*
function syntax example
*/


// what is a function?
//a block code, assigned to a name 

//fuction declaration
//name should describe whate function does
//has to match when we use function
function addTwoNumbers(){
  
}

//invoke a fuction
//fuction can have arguments
function addTwoNumbers(n1,n2) {
  console.log(n1 + n2);
}

addTwoNumbers(2,2);
addTwoNumbers(100,1);
addtwoNumbers(100000000,2)
addtwoNumbers()
addtwoNumbers()