/*
    debugging exercise
    there are several bugs in this program
    use the console to find the bugs
    some bugs will not appear in the console
    the finished version should look like this image:
    https://210.owen.cool/notes/debug/debug.png
*/

var faceSize = (100 * 3);

function setup() {
    createCanvas(640, 480);
    background(50);
    noStroke();
    fill("lightblue");
    ellipse(250, 350, faceSize); // face

    fill(0, 0, 0);
    ellipse (300, 200 + 100, 100); // right eye
    ellipse(200, 200 + 100, 100); // left eye
    ellipse(250, 300 + 100, 200, 110); // mouth

    fill("white");
    ellipse(150, 100, 200, 150);
    triangle(200, 200, 150, 175, 175, 150);

    fill("black");
    textSize(28);
    textFont("monospace");
    text("Nice work", 65, 110);
}
