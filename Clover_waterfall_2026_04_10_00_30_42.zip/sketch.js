/* Shatee Wardlaw 
feb,19,2025
Example of Adding to Text to p5
*/
//Get
function setup() {
  var c= createCanvas(400, 400);
  //gets rid of stroke 
  c.drawingContext.miterLimit = 2;
  console.log('textWidth');("Hello World!")
}
function draw() {
  background(220);
 //use a string for the text display
 //srting is any string (or sequence) of characters 
  fill('red');
  stroke('black');
  strokeWeight(10);
  textSize(30);
  //built in fonts 
  //htttps:www.cssfontstack.com
  textFont("Futura");
  stroke("green")
  strokeWeight(5)
  textWidth('Hello Wold!')
text("Hello world!",215 ,400);
  //googlefont
 textFont("Barrio"); 
 textSize(120);
 text("hi!", 200, 200); 
  
  textSize(12);
  textLeading(12* 1.5);
  textAlign(CENTER,BOTTOM);
   strokeWeight(1);
  text("There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.", 10, 370,390);



}