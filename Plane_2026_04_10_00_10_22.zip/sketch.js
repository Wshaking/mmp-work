function setup() {
  createCanvas(400, 400);
}
function draw() {
  //Airplane Window  
  background(220);
  fill("#fcf1de");
  ellipse(219,218,250,322);
  //inner Airplane window  
  ellipse(212,218,194,220)
  strokeWeight(10);
  stroke("#bfa29c");
  line(485, 410, 485, 83);
  strokeWeight(6);
  line(420, 255, 550, 245);
}

function mousePressed() {
    save ('Plane'.jpg);
}