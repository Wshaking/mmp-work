function setup() {
  createCanvas(400, 400);
  //draw squares/rects from the center
  rectMode(CENTER);
  strokeWeight(16);
}

function draw() {
  background(220);
  
  //set fill color
  fill(140,300,200);
  // set stroke outline  color
  stroke(240, 67, 99);
  square(200,200,400); // big square
  fill("#9da16a");// css color name 
  stroke("#FFE500");//css hex value 
  square(200,200,200);//medium square 
  noFill(30);
  //this circle show the top half has no fill color while the bottom has fill color 
  circle(200,120,200)
  fill(100-50,100-100,50);
  stroke(20-200);  
  fill(100-50,100-100,50);
  fill("#34eb37");
  //this is a side rectrangle with less of wight space with no storke
  rect(430,200,300-100);
  noStroke(-10);
  fill("#f04363")
  circle(100,200,100);
  
  function mousePressed() {
save("shapes.png");
} 

}