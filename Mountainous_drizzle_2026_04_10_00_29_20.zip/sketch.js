/*
Aniamation Rotation Example
*/

let r= 0;
let rSpeed = 0.05;

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  
  translate(200,200);
  
  r = r + rSpeed
  if (r > PI || r < 0){
   rSpeed = rSpeed * - 1 
  }
  rotate(r);
  
}