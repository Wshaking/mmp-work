/*
Shatee Wardlaw 3/17/25
Loop Statement Example*/


function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(220);
  var x= 50;
 while (x <= 200){
    ellipse(x, 50, 50);
   text(x, x, 50);
   x +=50;
  }
for (var x= 0; x <= 400; x += 50){
ellipse(x,200,50);
 text(x, x, 200);
}
  
  
  for(var y =50; y < height; y += 50){
    line(0, y, width, y);
  }
  

 for(var i = 0; i < 10; i++) {
   var x = i * 50;
   circle(x, 300, 50);
   text(i, x, 300);
   text(x, x, 300 + 10);

   var s = 100 - i*10;
   var s = map(i,0,9,200, 50);
   circle(400, 100, s)
 }


}






