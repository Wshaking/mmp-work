/* This is p5 Example 
Jan 24, 2024 
*/ 
/* multi-line comment*/
// Single-line comment


function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  //text (frameCount, 20, 20);
  //noStroke(); // turns off outline 
  //noFill(0);// turns off fill
  strokeWeight(4);
// shapes with origin,size 
  circle(200,200,200);
  square(200,200,200);
  ellipse(100,200,200,100);
  rect(10,10,300,50);
  
  //shapes with points
  point(50, 50)
}