/*
  this is my into p5 example
  Jan 27 2024
  */

/* mulit- line comment */
//single line comment

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  circle(200, 200, 200);
  square(200, 200, 200);
}
/* This is my Assignment 1 */
/* This is the look of a book with pages */
function draw() {
  background(220);
  noFill(20);
  // first page of the book/ cover
  triangle(400, 200, 10, 400, 250, 15);
  triangle(400, 200, 10, 400, 250, 150);
  //second page of the book
  triangle(400, 200, 10, 400, 250, 230);
  triangle(400, 200, 10, 400, 250, 20);
  //last pages of book
  line (200,100,10,400);
}
function mousePressed() {

save("shapes.png");
}