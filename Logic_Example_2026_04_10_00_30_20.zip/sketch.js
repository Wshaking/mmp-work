/*Shatee Wardlaw 
Mar,3,2025
*/

let drawPinkBackground = false;
let circleSize = 0;
 function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  
  //basic logic statement
  //if (condition){code block}
  
  //boolean value is true or flase 
  if (true){
    fill("lightblue");
    rect(0,0,width,height);
  }
  if (false){
    fill("pink");
   rect(0,0, width ,height);
  }
  if(drawPinkBackground){
    fill("pink");
    rect(0, 0, width, height);
  }
  //greater than 
  if (mouseX >200){
    fill("green");
    ellipse(200,200,200);
  }
  fill(0);
  textSize(40);
  text(mouseX,20,40);
  //less than 
  if(mouseX < 200){
    fill("green");
    rect(200,200,200)
    //>=, <=
    
    if(keyIsPressed);{
      fill('yellow');
      text("Hi", 200 , 200);
    }
    //13 is Enter Key
    if(keyIsDown("13")){
    fill("yellow")
      text("GoodBye", 200,240);
    }
    //Rest an Animation
    circle(200,200,circleSize);
    circleSize=circleSize + 2;
    if (circleSize > 300){
      circleSize=100;
    }
  }
}
/*
  if else example
*/

let stoplightProgress = 0;

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);

  // if else statement
  fill(255);
  if (mouseX > 200) {
    background("pink");
    rect(200, 0, 200, height);
  } else {
    background("yellow");
    rect(0, 0, 200, height);
  }

  // if, else if (x), else

  // stoplight
  let circleHeight = height / 3;
  
  if (mouseY < circleHeight) {
    fill("red");
    circle(100, height / 6, circleHeight);
  } else if (mouseY < circleHeight * 2) {
    fill("yellow");
    circle(100, height / 6 + circleHeight, circleHeight);
  } else {
    fill("green");
    circle(100, height / 6 + circleHeight * 2, circleHeight);
  }
  
  if (stoplightProgress < circleHeight) {
    fill("red");
    circle(300, height / 6, circleHeight);
  } else if (stoplightProgress < circleHeight * 2) {
    fill("yellow");
    circle(300, height / 6 + circleHeight, circleHeight);
  } else {
    fill("green");
    circle(300, height / 6 + circleHeight * 2, circleHeight);
  }
  
  stoplightProgress = stoplightProgress + 1;
  if (stoplightProgress > height) {
    stoplightProgress = 0;
  }
  
}
