function setup() {
  createCanvas(windowWidth, windowHeight);
  background("black");
  pattern();
  rectMode(CENTER);
  frameRate(2);
} function draw() {
  pattern();
  
} 

function pattern() {
  //netted loop & randomness loop with push & random rgb
  for (var x = 0; x <= width; x += 50) {
    for (var y = 0; y <= width; y += 40) {
      var columns = 52;
      var rows = 22;
      var w = width / columns;
      var h = height / rows;
      push();
      var r = map(y, 0, height, 0, 255);
      g = random(10, 255);
      b = random(0, 255);
      fill(r, g, b);
      rect(x, y, w, h);
      var s =random(-110, 10);
      rect(x, y, w + s, h + s);
    } 
    
    function mousePressed() {
      pattern();
    }
    //Randomness Fuction with pop
    if (random(1) > 0.8) {
      ellipse(x, y, w + s, w + h);
      pop();
    } else {
      rect(x, y, w + h, w + s)
    }
  }
}
