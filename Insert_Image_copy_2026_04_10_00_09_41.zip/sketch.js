//Under Sketch do Add Folder (name = images)
//Upload image (god.png, PythSoc.png) to Folder
function preload(){
  img1 =loadImage("images/god.png")
  img2 =loadImage("images/PythSoc.png")
}

function setup() {
  createCanvas(400, 400);
}

function draw() {
background(220);
image(img1,0,0,400,200);
image(img2,0,200,400,200);
}