/*
 Image Example
imagedused:https://www.pexels.com/photo/brown-wolf-on-green-grass-field-8583473/
by Aksinia Avelur
  
*/
//Variable declaration
//Use this to save the image date
//To be used by both preload and draw
var wolfdogImage;


function preload() {
wolfdogImage = loadImage("wolfdog.jpg"); 
  
}
function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  //draw the image 
  image(wolfdogImage, 0, -50, 400, 500)
}