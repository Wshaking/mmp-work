/*
Mar,10,25
Shatee wardlaw*/

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  
  //default transform
  circle(0,0,100);
  rect(20, 20 , 50);
  
  // transform is collection of properties
  //postion, rotation, scale
  
  
  translate(200,200);
   circle(0,0,100);
  rect(20, 20 , 50);
   
 // rotation - rotate around the origin 
  rotate(PI / 4);
  scale(2);
  circle(0, 0, 50);
  circle(0, 0, 50);
  rect(20, 20, 50);
 //tranform are cumulative
  push();
   rotate(PI / 4);
  scale(2);
  circle(25, 25, 50);
  rect(20, 20, 50);
  //pops off the last transformation from the stack
  pop();
  
  rotate(PI /4);
  circle(100, -100, 100);
  rect(20,20, 50);
  }
