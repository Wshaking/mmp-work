/* Shatee Wardlaw
2/6/25
Assiment #2 Color*/
// color mode will be rgb
 
function setup() {
  createCanvas(400,400);
rectMode(CENTER);
  colorMode(RGB);
  strokeWeight(20);
}
// This is the Fill & Stroke of the big square with light pick outline 
function draw() {
  background(220);
  fill("fcba03");
  square(200,200,400);
  stroke(211,120,75);
  noFill(30);
fill(212,222,110); 
  //This is the circle stroke & fill 
  circle(90,300,115); 
  stroke(0);
  //This is the rect stroke &fill
  fill("#90d6a6");
rect(300,200,100,200);
  stroke(100,200,100);
  //This is the quad stroke & fill 
  quad(200, 215, 196, 200, 208, 88, 84, 200);
  stroke(300,110,210);
  fill(121,50,101); 
}
function mousePressed(){
  save("shape.png")
}