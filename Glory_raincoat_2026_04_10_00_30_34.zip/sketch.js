/*
 postition variables
*/
 //declaring and defining variables
//or initializing
let x =200;
let y =200;
function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  //frog moves with mouse
  x= mouseX;
  y=mouseY;
  //frog charcter
  fill('green');
  noStroke();
  ellipse (x,y,100,40); // body
  
  circle(x-20, y-20, 20);// left eye
  circle(x+20, y-20, 20);// right eye
   
  ellipse(x-30,y+20, 30, 10);//left foot 
  ellipse(x+30,y+20, 30, 10);//right foot
  
}