function setup() {
  createCanvas(600, 400);
}

function draw() {
  background("lightblue");
  fill('green');
  noStroke();
  rect(0, 300, width, 100);
  
  // clouds 
  fill("white");
  cloud(100,100, 'white');
  cloud(200,50, 'gray');
  //tree
  fill('brown');
  rect(100,220, 20 , 100, 5);
  fill('green')
  circle(110,220,80);
}

function cloud(x,y,c){
  fill (c);
  circle(x,y,50);
  circle(x + 20, y + 20, 50);
  circle(x - 20, y + 20, 50);
}