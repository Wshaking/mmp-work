let n;

function setup() {
  createCanvas(600, 400);
  landscape();
  n = random(600);
  
}


function landscape() {
  background('lightblue');
  noStroke();
  fill("green")
   rect(0,330,width,330);
  fill('grey');
  triangle(330, 40, -70, 330, 410, 330); 
  
  for(var x = 0; x<= width; x+=50){
    var y = random(20, 140);
    cloud(x,y, "white");
    cloud(x,y +60, 'grey');
      var s = random(0,100);
    tree(x,220,s);
  }
  for (var x = - 100; x<=width; x+=50){
        var y = random(20,100);
    rain(x - 0, y,'blue');
  }
  // clouds 
   cloud(x, y + 10, 'white');
   cloud(x, y- 40, 'grey');
   cloud(x,50, 'greay')
  // trees
   tree(100,230,'brown');
   tree(200, 230,100 );
}

function mountain(x,y){
  noStroke();
  //mountiain 
  fill('grey');
      triangle(520, 371, 150, 240, 320, 210);
}
function cloud(x, y,c) {
  fill(c);
  circle(x, y, 50);
  circle(x + 20, y + 20, 50);
  circle(x - 20, y +20, 50);
}

function tree(x,y,s){
  fill('brown');
rect(x,y,20,100,5);
  fill('green');
  circle(x + 10,y,100);
}

function rain(x,y,s){
  
fill('darkblue')
ellipse(x- 5,y - 10,10,5);
}

 