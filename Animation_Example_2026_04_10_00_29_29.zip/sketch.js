/* 
animation example
"the bouncing dvd logo"
Shatee Wardlaw 3/10/25
*/
//position of the logo
let x =200;
let y=200;

let ySpeed=2;
let xSpeed=2;

let r = 200;
let g = 100;
let b = 250;
 function setup() {
  createCanvas(500, 400);
   textAlign(CENTER,CENTER);
}

function draw() {
  background(220);
  //draw logo
  ellipse(x , y, 50);
  text("DVD", x, y + 10);
  text("DVD", x, y  - 10);
  
  //animate the logo
  x = x + xSpeed;
  y = y + ySpeed;
  //bounce off the right side 
  //Or bounce off the left 
  if (x > width || x < 0){
    xSpeed = xSpeed * - 1
    r= random(127, 255)
    g= random(55, 100)
    b= random(127, 255)
    fill(r,g,b);
  }
  //bounce off the bottom side
  //Or bounce off the top
  if (y > height || y < 0 ){
   ySpeed = ySpeed * - 1
  }
  if(x < 0){
    x=width;
  }
}

