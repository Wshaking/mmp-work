/* Carmen Herrera artwork 
https://whitney.org/exhibitions/carmen-herrera#artworks*/
function setup() {
  createCanvas(400, 600);
}

function draw() {
  background(220);
  fill("darkred");
  //first top line of artwork 
  rect(10,190,140,10);
  noStroke();
  //first top bottom line of artwork 
  rect(140,-1,12,200);
  
  //second bottom line of artwork
  rect(220,220,10,400);
  noStroke();
  //second top of artwork 
  rect(230,220,140,10);

}
function mousePressed(){
  save("shape.png")
}