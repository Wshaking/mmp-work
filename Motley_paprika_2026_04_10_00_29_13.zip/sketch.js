

let x=200;
let y=200;

function setup() {
  createCanvas(500, 400);
}

function draw() {
  background(220);
  
  ellipse(x, y, 50);
  text("DVD", x,y + 10);
  text("DVD", x,y -10 )
  x=x +1;
  y=y +1;
