/*
Shatee Wardlaw KeyBoard & Sound 
Sound So
https://freesound.org/people/PaynesBeats/sounds/351445/
*/
var bgMusic;
// background music 
function preload() {
bgMusic=loadSound('return.wav')
}
function setup() {
  createCanvas(400, 400);
}

function draw(){
  background(220)
  rect(300,150,200,400);
  rect(10,15,150,200);
  // change for background 
  function buttion(x, y, w, h,) {
    if(mouseX > x && mouseX < x + w && 
    mouseY > y && mouseY < y + h){
     fill("white");
     }else{
      fill('blue');
     }
  rect(x,y,w,h);

	// display key value
	textSize(40);
	textAlign(CENTER, CENTER);
	text(key, width/2, height/2);
}
    
  
  }
function keyPressed(){
  if(keyCode== 74){//"j key"
    bgMusic.play(); 
    
  }
}
