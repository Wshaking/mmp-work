let currentPanle = 1;
// image
var jhnImage;
let x = 640;
let y = 1137;
let img;
function preload() {
  jhnImage = loadImage("jhn.jpeg");
}
console.log()

function setup() {
  createCanvas(400, 400);
}
function mousePressed() {
  currentPanle = currentPanle + 1;
  if (currentPanle > 6) {
    currentPanle = 1;
  }
}
function draw() {
  background(400);

  if (currentPanle == 1) {
    //1st comic panel

    //black circle
    fill("black");
    circle(100, 200, 150);

    //text from black circle
    fill("black");
    text("Did you see that new Horror Movie", 20, 30);

    //pink rect
    fill("pink");
    rect(200, 100, 70, 200);
  } else if (currentPanle == 2) {
    // 2nd comic panle

    //black circle
    fill("black");
    circle(100, 200, 150);

    //pink rect
    fill("pink");
    rect(200, 100, 70, 200);

    //text from pink rect
    fill("black");
    text("Not yet Going this Weekend", 200, 30);
  } else if (currentPanle == 3) {
    //3rd comic panle

    //black circle
    fill("black");
    circle(100, 200, 150);

    fill("black");
    text("Did u hear that knock knock...", 20, 30);

    //pink rect
    fill("pink");
    rect(200, 100, 70, 200);
    
  } else if (currentPanle == 4) {
    //4th comic panle
    //black circle
    fill("black");
    circle(100, 200, 150);

    //pink rect
    fill("pink");
    rect(200, 100, 70, 200);

    //text from pink rect
    fill("black");
    text("Yeah look behind you", 200, 30);
  } else if (currentPanle == 5) {
    //5th comic panle

    //black circle
    fill("black   ");
    circle(100, 200, 150);

    //pink rect
    fill("pink");
    rect(200, 100, 70, 200);
  } else if (currentPanle == 6) {
    image(jhnImage,0,0);
  }
}
  
function mousePressed() {
    save ('Comic'.jpg);
} {
  
}