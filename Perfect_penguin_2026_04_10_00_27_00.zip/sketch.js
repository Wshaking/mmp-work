//function declartion , definition
function sandwich(){
 console.log("I making a sandwich");
 console.log('It is a' + sandwichType + 'sandwich.');
}

//invoke, run, call funtion
sandwich("peanut butter and jelly snadwich");
sandwich("bologna");

function greet(){
  
} 

function setup() {
  
  
  
  
}