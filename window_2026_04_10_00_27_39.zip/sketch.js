function setup() {
  createCanvas(650, 400);
}

function draw() {
  background(220);
  for (var x = 50; x <= height; x+=200  ){
    var y = 100;
    // Main Windows Frame 
    rect(x,y,100,200)
    rect(x + 5, y + 10, 90, 140);
      
    
  } 
  // Inner window Frame 
    for (var x = 50; x <= width; x += 200);{
      var y = 100;
  // row of lines as blinds on window
     line(x + 5 ,y + 23, 144,123,);
     line(x + 5 ,y + 33, 144,133,);
     line(x + 5 ,y + 42, 144,142,);
     line(x + 5 ,y + 56, 144,156,);
}
}