let b = true;
let img;
let showImage = false; 
function preload() {
img=loadImage("https://images.pexels.com/photos/31050184/pexels-photo-31050184.jpeg");
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  rectMode(CENTER);
  frameRate(2);
}

function draw() {
  background("red");
  pattern();
  if (showImage) {
    image(img, 0, 0, width, height);
  }
  if (b.hide){
   image(img,0,0,width,height);
    
  }
}
//This is Pattern
function pattern() {
  let columns = 52;
  let rows = 11;
  let w = width / columns;
  let h = height / rows;
// This is the Patteren Randomness
  for (let x = 0; x <= width; x += 10) {
    for (let y = 1; y <= height; y += 10) {
      push();
      let r = map(y, 0, height, 0, 255);
      let g = random(10, 255);
      let b = random(0, 255);
      fill(r, g, b);
      circle(x, y, w);
      let s = random(-110, 10);
      rect(x, y, w + s, h + s);
      pop();
    }
  }
}
//Show & Hides Image when Key is press 
function keyPressed() {
  if (key=== "Enter") {
    showImage = true;
    console.log("Enter keypressed — now showing image.");
     
  } 
  if (key ==="b"){
     showImage =false
    console.log("b key pressed-now hides image.");
     }
}