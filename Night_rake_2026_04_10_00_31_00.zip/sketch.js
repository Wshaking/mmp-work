/*
debugging example
*/
function setup();
{
  createCanvas(400, 400);
background(200);
  
  
 function draw();
  ellipse(100,100,50);
  rect(200, 200, 100, 50 * 10);
}
//framing the problem
//what did you expect? what happened instead?

//fatal errors-program doesn't run, or stops running 
//red text appears in the console
//conceptaul-no error in console ,program doesn't run the way we expect