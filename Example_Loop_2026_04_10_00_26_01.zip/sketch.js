/*
nested for loop example
4/7/25
Shatee Wardlaw
*/
function setup() {
  createCanvas(400, 400);
  pattern();
}
function pattern() {
  background(220);
 noStroke();
  //nested for loop
  for (var x = 0; x <= width; x += 50) {
    for (var y = 0; y <= width; y += 50){
      
    
      //face
      //fill('purple');
      //ellipse(x, y, 50); //head
      //fill('lightblue');
    //ellipse(x + 10, y - 10, 10);// left eye
    //ellipse(x - 10, y - 10, 10);// right eye
    rect(x - 10,y + 10, 20, 5, 2); // mouth
  }
}
 // using transformation 
  for (var x = 0; x <= width; x += 50) {
    for (var y = 0; y <= width; y += 50){
    fill('green');
    push();
    translate(x,y);
    triangle(0, 0, 50, 25, 25, 50);
    circle(30,20, 20);
    pop();
   }
}
}