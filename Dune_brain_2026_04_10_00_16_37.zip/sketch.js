/*Shatee Wardlaw rectangle Example
4/28/25
*/
function setup() {
  createCanvas(400, 400);


}

function draw() {
  background(220);
  buttion(50,50,100,50);
  buttion(50,150,100,50);
  buttion(50,250,200,50);
  buttion(300,50,50,100);

}
 function buttion(x, y, w, h ) {
  if(mouseX > x && mouseX < x + w && 
    mouseY > y && mouseY < y + h){
     fill('yellow');
     }else{
      fill('white');
     }
  rect(x,y,w,h);
}